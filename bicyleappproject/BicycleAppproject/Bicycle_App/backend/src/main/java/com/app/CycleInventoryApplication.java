package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CycleInventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(CycleInventoryApplication.class, args);
	}

}