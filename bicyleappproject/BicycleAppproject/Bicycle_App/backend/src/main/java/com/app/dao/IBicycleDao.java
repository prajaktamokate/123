package com.app.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Bicycles;


public interface IBicycleDao extends JpaRepository<Bicycles, Integer> {
	
}
