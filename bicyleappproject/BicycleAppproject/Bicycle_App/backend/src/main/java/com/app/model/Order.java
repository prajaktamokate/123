package com.app.model;

import java.util.Arrays;

import com.app.pojos.OrderItems;
import com.app.pojos.CustomerAddress;
import com.app.pojos.Bicycles;

public class Order {
	private OrderItems[] orderItems;
	private CustomerAddress shippingAddress;
	private int user;

	public Order() {
		// TODO Auto-generated constructor stub
	}

	public Order(OrderItems[] orderItems, CustomerAddress shippingAddress, int user) {
		super();
		this.orderItems = orderItems;
		this.shippingAddress = shippingAddress;
		this.user = user;
	}

	public OrderItems[] getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(OrderItems[] orderItems) {
		this.orderItems = orderItems;
	}

	public CustomerAddress getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(CustomerAddress shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public int getUser() {
		return user;
	}

	public void setUser(int user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Order [orderItems=" + Arrays.toString(orderItems) + ", shippingAddress=" + shippingAddress + ", user="
				+ user + "]";
	}

	public static class ImageDTO {
		private String name, type;
		private byte[] data;

		public ImageDTO() {

		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public byte[] getData() {
			return data;
		}

		public void setData(byte[] data) {
			this.data = data;
		}

	}

	public static class ProductModal {
		private Bicycles product;
		private ImageDTO image;

		public Bicycles getProduct() {
			return product;
		}
		public void setProduct(Bicycles product) {
			this.product = product;
		}
		public ImageDTO getImage() {
			return image;
		}
		public void setImage(ImageDTO image) {
			this.image = image;
		}

	}
}
