package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.IBicycleDao;
import com.app.pojos.Bicycles;


@Service
@Transactional
public class ProductsServiceImpl implements IBicycleService {

	@Autowired
	private IBicycleDao productDao;
	
	
	@Override
	public List<Bicycles> getAllProducts() {
		  return productDao.findAll();
	}


	@Override
	public Bicycles saveProductsDetails(Bicycles transientProducts) {
		
		return productDao.save(transientProducts);
	}


	@Override
	public Bicycles getProductsDetailsById(int productId) {
		return productDao.findById(productId).get();
	}


	@Override
	public String deleteProduct(int userId) {
		productDao.deleteById(userId);
		return "Product Details Deleted";
	
	}


	@Override
	public Bicycles updateProductDetails(Bicycles detachedProduct) {
		return productDao.save(detachedProduct);
	}

}
