import React from "react";
import "./HeadingScreen.css"
export const HeadingScreen = () => {

    return (
        <div class="waviy" style={{marginTop:"60px"}}>
            <h1 className="newHeader">
                <span>The&nbsp;bicycle&nbsp;</span>
                <span>is&nbsp;</span>
                <span>a&nbsp;</span>
                <span>curious</span>
                <span>vehicle.&nbsp;</span>
                <span>Its&nbsp;</span>
                <span>passenger&nbsp;</span>
                <span>is&nbsp;</span>
                <span>its</span>
                <span>engine.</span>
                {/* <span>you</span>
                <span>place</span>
                <span>on</span>
                <span>your</span>
                <span>own</span>
                <span>thinking.</span> */}
            </h1>
        </div>
    );
}
// "The bicycle is a curious vehicle. Its passenger is its engine."