package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="bicycle_tbl")
public class Bicycles extends BaseEntity{
    @Column(length=50)
	private String name = "";
    private String category = "";
    
    private String images = "\\images\\b1.png";
    @Column(name="type")
    private String brand = "";
    private String description = "";
    private double price = 0;
    @Column(name="count_in_stock")
    private int countInStock = 0;
    @Column(columnDefinition = "double default 4.5")
    private Double rating=4.5;
    @Column(columnDefinition = "integer default 125")
    private Integer numReviews=125;
     
	public Bicycles() {
		System.out.println("in products constr:"+getClass().getName());
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public int getCountInStock() {
		return countInStock;
	}

	public void setCountInStock(int countInStock) {
		this.countInStock = countInStock;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public Integer getNumReviews() {
		return numReviews;
	}

	public void setNumReviews(Integer numReviews) {
		this.numReviews = numReviews;
	}

	@Override
	public String toString() {
		return "Products [name=" + name + ", category=" + category + ", images=" + images + ", brand=" + brand
				+ ", description=" + description + ", price=" + price + ", countInStock=" + countInStock + ", rating="
				+ rating + ", numReviews=" + numReviews + "]";
	}



	public Bicycles(String name, String category, String images, String brand, String description, double price,
					int countInStock, double rating, int numReviews) {
		super();
		this.name = name;
		this.category = category;
		this.images = images;
		this.brand = brand;
		this.description = description;
		this.price = price;
		this.countInStock = countInStock;
		this.rating = rating;
		this.numReviews = numReviews;
	}

	
	
	
	
}
