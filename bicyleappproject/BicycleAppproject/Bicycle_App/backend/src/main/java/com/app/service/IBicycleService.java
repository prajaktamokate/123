package com.app.service;

import java.util.List;

import com.app.pojos.Bicycles;

public interface IBicycleService {
    List<Bicycles> getAllProducts();
    
    Bicycles saveProductsDetails(Bicycles transientProducts);
    
    Bicycles getProductsDetailsById(int productId);
    
    String deleteProduct(int userId);
    
    Bicycles updateProductDetails(Bicycles detachedProduct);
    
    
    
    
    
    
}
