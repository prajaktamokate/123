import React, { useEffect, useState } from 'react';
import Product from '../components/Product';
import LoadingBox from '../components/LoadingBox';
import MessageBox from '../components/MessageBox';
import { useDispatch, useSelector } from 'react-redux';
import { listProducts } from '../actions/productActions';

export default function HomeScreen() {
  const dispatch = useDispatch();
  const productList = useSelector((state) => state.productList);
  const { loading, error, products } = productList;
  var date1 = new Date();
  var year = date1.toLocaleString("default", { year: "numeric" });
  var month = date1.toLocaleString("default", { month: "2-digit" });
  var day = date1.toLocaleString("default", { day: "2-digit" });
  const date=year + '-' + month + '-' + day;

  useEffect(() => {
    dispatch(listProducts());
  }, [dispatch]);

  let [cycles, setCycles] = useState(null);

  useEffect(() => {
    let productList = products?.map(product => {
      return <Product key={product._id} product={product} curDate = {date}></Product>;
    });
    setCycles(productList)
  },[products, date]);

  return (

    <div>
      {loading ? (
        <LoadingBox></LoadingBox>
      ) : error ? (
        <MessageBox variant="danger">{error}</MessageBox>
      ) : (
        <div className="row center">
          {cycles}
        </div>
      )}
    </div>
  );
}