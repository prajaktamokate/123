import React, { useState, useEffect } from "react";
import { useSelector } from 'react-redux';
import axios from "axios";
import MessageBox from "../components/MessageBox";
import _ from "lodash";
function Myorders(props) {
  const userId = props.match.params.userId;
  const userSignin = useSelector((state) => state.userSignin);
  const { userInfo } = userSignin;
  let [orders, setOrders] = useState([]);
  const isAdmin=userInfo.isAdmin==null?false:true;
  useEffect(() => {
    axios
      .get("http://localhost:8080/user/orders/" + userId)
      .then(response => {
        var output;
        if(isAdmin){
          output =
          _(response.data)
            .groupBy('product')
            .map((objs, key) => {
                return {
                  'name': objs[0].name,
                  "images": objs[0].images,
                  'product': key,
                  'qty': _.sumBy(objs, 'qty'),
                  'price': _.sumBy(objs, 'qty') * objs[0].price
                }}
            ).value();
        }else{
          output=response.data
        }
        console.log(output);
        setOrders(output)
      });
  }, [userId,isAdmin]);

  return (
    <div className="col-2">
      <h1 style={{ color: "white" }}>Order Details</h1>
      {orders.length === 0 ? (
        <MessageBox>
          You don't have any orders
        </MessageBox>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Bicycle</th>
              <th>Name</th>
              {isAdmin?'':<th>Date</th>}
              <th>Number of bicycle</th>
              <th>Total bill</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order._id}>
                <td><img
                  src={order.images}
                  alt={order.name}
                  className="small"
                ></img></td>
                <td>{order.name}</td>
                {isAdmin?'':<td>{order.date}</td>}
                <td>{order.qty}</td>
                <td>₹{order.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default Myorders;
